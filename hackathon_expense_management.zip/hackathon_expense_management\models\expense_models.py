# -*- coding: utf-8 -*-

import requests
import logging
from datetime import date
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class ExpenseCategory(models.Model):
    """Expense categories for classification"""
    _name = 'expense.category'
    _description = 'Expense Category'
    _order = 'name'

    name = fields.Char(string='Category Name', required=True)
    
    _sql_constraints = [
        ('name_unique', 'unique(name)', 'Category name must be unique!')
    ]


class ExpenseApprovalRule(models.Model):
    """Rules for expense approval workflow"""
    _name = 'expense.approval.rule'
    _description = 'Expense Approval Rule'
    _order = 'name'

    name = fields.Char(string='Rule Name', required=True)
    rule_type = fields.Selection([
        ('percentage', 'Percentage Based'),
        ('specific_user', 'Specific User'),
        ('hybrid', 'Hybrid Logic')
    ], string='Rule Type', required=True, default='percentage')
    
    approval_percentage = fields.Float(
        string='Approval Percentage',
        help='Percentage of approvers required to approve the expense'
    )
    
    specific_approver_id = fields.Many2one(
        'res.users',
        string='Specific Approver',
        help='Specific user who must approve this type of expense'
    )
    
    hybrid_logic = fields.Selection([
        ('OR', 'OR Logic'),
        ('AND', 'AND Logic')
    ], string='Hybrid Logic', default='OR',
       help='Logic to apply when combining percentage and specific user approval')

    @api.constrains('rule_type', 'approval_percentage', 'specific_approver_id')
    def _check_rule_configuration(self):
        for rule in self:
            if rule.rule_type == 'percentage' and not rule.approval_percentage:
                raise ValidationError("Approval percentage is required for percentage-based rules.")
            if rule.rule_type == 'specific_user' and not rule.specific_approver_id:
                raise ValidationError("Specific approver is required for specific user rules.")
            if rule.rule_type == 'percentage' and (rule.approval_percentage < 0 or rule.approval_percentage > 100):
                raise ValidationError("Approval percentage must be between 0 and 100.")


class ExpenseApproverLine(models.Model):
    """Approval lines for expense claims"""
    _name = 'expense.approver.line'
    _description = 'Expense Approver Line'
    _order = 'sequence, id'

    claim_id = fields.Many2one('expense.claim', string='Expense Claim', required=True, ondelete='cascade')
    approver_id = fields.Many2one('res.users', string='Approver', required=True)
    sequence = fields.Integer(string='Sequence', default=10)
    
    status = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string='Status', default='pending', required=True)
    
    comments = fields.Text(string='Comments')
    approval_date = fields.Datetime(string='Approval Date')

    @api.model
    def create(self, vals):
        """Override create to ensure proper sequence"""
        if not vals.get('sequence'):
            claim_id = vals.get('claim_id')
            if claim_id:
                max_sequence = self.search([('claim_id', '=', claim_id)], order='sequence desc', limit=1)
                vals['sequence'] = (max_sequence.sequence or 0) + 10
        return super().create(vals)


class ExpenseClaim(models.Model):
    """Main expense claim model"""
    _name = 'expense.claim'
    _description = 'Expense Claim'
    _order = 'date desc, id desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Expense Description', required=True, tracking=True)
    
    employee_id = fields.Many2one(
        'hr.employee',
        string='Employee',
        required=True,
        default=lambda self: self._get_default_employee(),
        tracking=True
    )
    
    amount_source = fields.Float(
        string='Amount (Source Currency)',
        required=True,
        tracking=True
    )
    
    source_currency_id = fields.Many2one(
        'res.currency',
        string='Source Currency',
        required=True,
        default=lambda self: self.env.company.currency_id,
        tracking=True
    )
    
    company_currency_id = fields.Many2one(
        'res.currency',
        string='Company Currency',
        related='company_id.currency_id',
        store=True
    )
    
    amount_company = fields.Float(
        string='Amount (Company Currency)',
        compute='_compute_amount_company',
        store=True,
        tracking=True
    )
    
    date = fields.Date(
        string='Expense Date',
        required=True,
        default=date.today,
        tracking=True
    )
    
    category_id = fields.Many2one(
        'expense.category',
        string='Category',
        tracking=True
    )
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('in_progress', 'In Progress'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string='State', default='draft', required=True, tracking=True)
    
    approver_line_ids = fields.One2many(
        'expense.approver.line',
        'claim_id',
        string='Approvers'
    )
    
    approval_rule_id = fields.Many2one(
        'expense.approval.rule',
        string='Approval Rule'
    )
    
    receipt_attachment_id = fields.Many2one(
        'ir.attachment',
        string='Receipt Attachment',
        help='Upload receipt image for OCR processing'
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    active = fields.Boolean(
        string='Active',
        default=True,
        help='Set to false to archive the expense claim'
    )
    
    # Computed fields for approval status
    pending_approvals = fields.Integer(
        string='Pending Approvals',
        compute='_compute_approval_status'
    )
    
    total_approvers = fields.Integer(
        string='Total Approvers',
        compute='_compute_approval_status'
    )

    @api.model
    def _get_default_employee(self):
        """Get current user's employee record"""
        return self.env.user.employee_id

    @api.depends('amount_source', 'source_currency_id', 'company_currency_id')
    def _compute_amount_company(self):
        """Compute amount in company currency using external API"""
        for record in self:
            if not record.amount_source or not record.source_currency_id:
                record.amount_company = 0.0
                continue
                
            # If same currency, no conversion needed
            if record.source_currency_id == record.company_currency_id:
                record.amount_company = record.amount_source
                continue
            
            # Get conversion rate from external API
            try:
                rate = self._get_conversion_rate(
                    record.source_currency_id.name,
                    record.company_currency_id.name
                )
                record.amount_company = record.amount_source * rate
            except Exception as e:
                _logger.error(f"Currency conversion failed: {str(e)}")
                # Fallback to Odoo's built-in currency conversion
                record.amount_company = record.source_currency_id._convert(
                    record.amount_source,
                    record.company_currency_id,
                    record.company_id,
                    record.date or date.today()
                )

    def _get_conversion_rate(self, from_currency, to_currency):
        """Get conversion rate from external API"""
        try:
            # Use the external API for conversion rates
            url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            rates = data.get('rates', {})
            
            if to_currency not in rates:
                raise UserError(f"Conversion rate not found for {to_currency}")
                
            return rates[to_currency]
            
        except requests.RequestException as e:
            _logger.error(f"API request failed: {str(e)}")
            raise UserError(f"Failed to fetch conversion rate: {str(e)}")
        except Exception as e:
            _logger.error(f"Conversion rate calculation failed: {str(e)}")
            raise UserError(f"Currency conversion error: {str(e)}")

    @api.depends('approver_line_ids.status')
    def _compute_approval_status(self):
        """Compute approval status counts"""
        for record in self:
            record.total_approvers = len(record.approver_line_ids)
            record.pending_approvals = len(record.approver_line_ids.filtered(
                lambda x: x.status == 'pending'
            ))

    def action_submit(self):
        """Submit expense for approval"""
        if self.state != 'draft':
            raise UserError("Only draft expenses can be submitted.")
        
        if not self.approver_line_ids:
            raise UserError("Please add at least one approver before submitting.")
        
        self.state = 'submitted'
        
        # Send notification to approvers
        self.message_post(
            body=f"Expense claim '{self.name}' has been submitted for approval.",
            subject="Expense Submitted for Approval"
        )
        
        # Process OCR if receipt is attached
        if self.receipt_attachment_id:
            self._process_receipt_ocr()

    def action_approve(self):
        """Approve expense (for current user)"""
        current_user = self.env.user
        approver_line = self.approver_line_ids.filtered(
            lambda x: x.approver_id.id == current_user.id and x.status == 'pending'
        )
        
        if not approver_line:
            raise UserError("You are not authorized to approve this expense or it's already processed.")
        
        approver_line.write({
            'status': 'approved',
            'approval_date': fields.Datetime.now()
        })
        
        # Check if all required approvals are received
        if self._check_approval_complete():
            self.state = 'approved'
            self.message_post(
                body=f"Expense claim '{self.name}' has been fully approved.",
                subject="Expense Approved"
            )
        else:
            self.state = 'in_progress'
            self.message_post(
                body=f"Expense claim '{self.name}' approved by {current_user.name}. Waiting for additional approvals.",
                subject="Expense Partially Approved"
            )

    def action_reject(self):
        """Reject expense (for current user)"""
        current_user = self.env.user
        approver_line = self.approver_line_ids.filtered(
            lambda x: x.approver_id.id == current_user.id and x.status == 'pending'
        )
        
        if not approver_line:
            raise UserError("You are not authorized to reject this expense or it's already processed.")
        
        approver_line.write({
            'status': 'rejected',
            'approval_date': fields.Datetime.now()
        })
        
        self.state = 'rejected'
        self.message_post(
            body=f"Expense claim '{self.name}' has been rejected by {current_user.name}.",
            subject="Expense Rejected"
        )

    def _check_approval_complete(self):
        """Check if approval process is complete based on approval rule"""
        if not self.approval_rule_id:
            # If no rule, require all approvers to approve
            return all(line.status == 'approved' for line in self.approver_line_ids)
        
        rule = self.approval_rule_id
        approved_count = len(self.approver_line_ids.filtered(lambda x: x.status == 'approved'))
        total_count = len(self.approver_line_ids)
        
        if rule.rule_type == 'percentage':
            required_approvals = (rule.approval_percentage / 100) * total_count
            return approved_count >= required_approvals
        
        elif rule.rule_type == 'specific_user':
            specific_approved = self.approver_line_ids.filtered(
                lambda x: x.approver_id.id == rule.specific_approver_id.id and x.status == 'approved'
            )
            return bool(specific_approved)
        
        elif rule.rule_type == 'hybrid':
            percentage_met = approved_count >= ((rule.approval_percentage / 100) * total_count)
            specific_approved = bool(self.approver_line_ids.filtered(
                lambda x: x.approver_id.id == rule.specific_approver_id.id and x.status == 'approved'
            ))
            
            if rule.hybrid_logic == 'OR':
                return percentage_met or specific_approved
            else:  # AND logic
                return percentage_met and specific_approved
        
        return False

    def _process_receipt_ocr(self):
        """Process receipt using OCR functionality"""
        if not self.receipt_attachment_id:
            return
        
        try:
            # Import OCR controller function
            from ..controllers.ocr_controller import process_receipt_ocr
            ocr_data = process_receipt_ocr(self.receipt_attachment_id.id)
            
            # Update expense with OCR data if found
            if ocr_data.get('amount'):
                try:
                    extracted_amount = float(ocr_data['amount'])
                    if not self.amount_source:  # Only update if not already set
                        self.amount_source = extracted_amount
                except ValueError:
                    _logger.warning(f"Could not convert extracted amount '{ocr_data['amount']}' to float")
            
            if ocr_data.get('date') and not self.date:
                try:
                    from datetime import datetime
                    extracted_date = datetime.strptime(ocr_data['date'], '%Y-%m-%d').date()
                    self.date = extracted_date
                except ValueError:
                    _logger.warning(f"Could not parse extracted date '{ocr_data['date']}'")
            
            # Log vendor information
            if ocr_data.get('vendor'):
                self.message_post(
                    body=f"OCR detected vendor: {ocr_data['vendor']}",
                    subject="OCR Processing Complete"
                )
                
        except Exception as e:
            _logger.error(f"OCR processing failed: {str(e)}")
            self.message_post(
                body=f"OCR processing failed: {str(e)}",
                subject="OCR Processing Error"
            )

    @api.constrains('amount_source')
    def _check_amount_positive(self):
        for record in self:
            if record.amount_source <= 0:
                raise ValidationError("Expense amount must be positive.")

    @api.constrains('date')
    def _check_date_not_future(self):
        for record in self:
            if record.date > date.today():
                raise ValidationError("Expense date cannot be in the future.")


class HrEmployeeInherit(models.Model):
    """Extend HR Employee with manager approver flag"""
    _inherit = 'hr.employee'

    x_is_manager_approver = fields.Boolean(
        string='Is Manager Approver',
        help='Check this if the employee can approve expenses as a manager'
    )